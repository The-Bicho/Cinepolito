-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-11-2024 a las 04:05:53
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cinepolito`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `ID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Apellido` varchar(100) NOT NULL,
  `Correo` varchar(100) NOT NULL,
  `Telefono` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`ID`, `Nombre`, `Apellido`, `Correo`, `Telefono`) VALUES
(1, 'Juan', 'Pérez', 'juanperez@example.com', '5551234567'),
(2, 'María', 'García', 'mariagarcia@example.com', '5552345678'),
(3, 'Carlos', 'López', 'carloslopez@example.com', '5553456789');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id` int(11) NOT NULL,
  `id_pelicula` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `asientos` varchar(255) DEFAULT NULL,
  `numero_asientos` int(11) DEFAULT NULL,
  `total_pagar` decimal(10,2) DEFAULT NULL,
  `metodo_pago` varchar(50) DEFAULT NULL,
  `fecha_compra` timestamp NOT NULL DEFAULT current_timestamp(),
  `asientos_array` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `peliculas`
--

CREATE TABLE `peliculas` (
  `ID` int(11) NOT NULL,
  `Pelicula` varchar(100) NOT NULL,
  `Estreno` date NOT NULL,
  `Clasificacion` varchar(50) NOT NULL,
  `Genero` varchar(50) NOT NULL,
  `Precio` float NOT NULL,
  `Duracion` int(11) NOT NULL,
  `Idioma` varchar(50) NOT NULL,
  `Sinopsis` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `peliculas`
--

INSERT INTO `peliculas` (`ID`, `Pelicula`, `Estreno`, `Clasificacion`, `Genero`, `Precio`, `Duracion`, `Idioma`, `Sinopsis`) VALUES
(1, 'Gladiador 2', '2024-12-15', 'B15', 'Acción', 56, 155, 'Español', 'Gladiador 2: La lucha por la justicia sigue en esta secuela, donde Maximus busca venganza contra los corruptos del Imperio Romano.'),
(2, 'Overlord El Reino Sagrado', '2024-11-22', 'C', 'Fantasia', 56, 130, 'Español', 'Overlord El Reino Sagrado: Un grupo de soldados luchan contra criaturas no-muertas en la Segunda Guerra Mundial, enfrentando horrores sobrenaturales.'),
(3, 'Robot Salvaje', '2024-12-01', 'A', 'Ciencia Ficción', 56, 120, 'Español', 'Robot Salvaje: Un robot desechado por la humanidad lucha por encontrar su propósito mientras se enfrenta a una sociedad que lo rechaza.'),
(4, 'Terrifier 3', '2024-10-31', 'D', 'Terror', 56, 95, 'Español', 'Terrifier 3: El asesino enmascarado Art the Clown regresa, desatando una ola de terror en una nueva ciudad.'),
(5, 'Wicked', '2024-11-25', 'A', 'Musical', 56, 105, 'Español', 'Wicked: Un musical basado en el mundo de Oz, que cuenta la historia de la bruja mala y su relación con la bruja buena.');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_pelicula` (`id_pelicula`);

--
-- Indices de la tabla `peliculas`
--
ALTER TABLE `peliculas`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `peliculas`
--
ALTER TABLE `peliculas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`id_pelicula`) REFERENCES `peliculas` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
